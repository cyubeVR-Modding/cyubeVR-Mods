Block Factory v04 for cyubeVR

This mod makes 100 copies of any block you choose.

To install: 
   Place the folder "BlockFactory__V1"  into C:\Program Files (x86)\Steam\steamapps\common\cyubeVR\cyubeVR\Mods\APIMods
   Place all block folders into C:\Program Files (x86)\Steam\steamapps\common\cyubeVR\cyubeVR\Mods\Blocks

To use this mod:
   -- Craft the custom block called "Block Factory".  You can find the recipe under the "Mod Blocks" category in the Crafting Recipes tab.

   -- Place the Block Factory block next to the block that you want to copy.

   -- Hit the Block Factory block with any axe type to set the copy direction.  The arrow should be pointing away from the block to be copied and towards where the copies will be placed.

   -- Hit the Block Factory block with the stick.  A group of blocks 5 wide x 5 deep x 4 high of the same type as your input block will be generated at the point of the arrow.  Any blocks already in the output area will be replaced by the newly generated blocks.

   -- To remove the Block Factory block, hit it with any axe type until it returns to its original state (no arrows).  It can then be broken with a pickaxe.

Version History:
   v04: Fixed incorrect number of copies being placed.
        Reworded readme and tutorial with clearer instructions.

   v03: Added ability to change copy direction.
        Added in-game tutorial page.

   v02: Compatibility update for cyubeVR beta 51.29.  Now can copy torches.

   v01: First release version.
   