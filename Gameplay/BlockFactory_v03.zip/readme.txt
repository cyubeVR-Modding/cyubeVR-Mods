Block Factory v03 for cyubeVR

This mod makes 100 copies of any block you choose.

To install: 
   Place the folder "BlockFactory__V1"  into C:\Program Files (x86)\Steam\steamapps\common\cyubeVR\cyubeVR\Mods\APIMods
   Place all folders inside the Blocks folder of this zip file into C:\Program Files (x86)\Steam\steamapps\common\cyubeVR\cyubeVR\Mods\Blocks

To use this mod:
   -- Craft the custom block called "Block Factory".  You can find the recipe under the "Mod Blocks" category in the Crafting Recipes tab.

   -- Place the Block Factory block next to the block that you want to copy.

   -- Hit the Block Factory block with any axe type to set the copy direction, with the arrow pointing to where the copies will be placed.  The block you want to copy should be at the base of the arrow.

   -- Hit the Block Factory block with the stick.  A group of blocks 5 wide x 5 deep x 4 high of the same type as your input block will be generated at the point of the arrow.

   -- To remove the Block Factory block, hit it with any axe type until it returns to its original state (no arrows).  It can then be broken with a pickaxe.

Notes:
   -- Once the Block Factory block has been hit with an axe, it can no longer be moved with the block placement tool.  It must be broken and placed again in order to be moved.

   -- Any blocks already in the output area will be replaced by the newly generated blocks.


Version History:
   v03: Added ability to change copy direction.
        Added in-game tutorial page

   v02: Compatibility update for cyubeVR beta 51.29.  Now can copy torches.

   v01: First release version.
   