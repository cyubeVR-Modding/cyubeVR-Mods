Placeable Foliage
by Quill Inkwell
Version 0.2

Installation Instructions:
===================================
The following zip packaged to allow for easy installation of the Mod into your game.
Simply extract the contents of the provided zip file into your CyubeVR Mods Folder.
"cyubeVR/cyubeVR/Mods"
If you are updating the mod allow it overwrite any existing mod files it encounters.

Once installed be sure to restart your cyubeVR and you should be able to craft any 2 dye or grass items together
to get their placeable block form. When you place the crafted block it should automatically be replaced by it's
foliage counterpart.

Uninstallation:
===================================
Simply delete the PlaceableFoliage__V1 mod from the "APIMods" folder.
To remove the blocks delete any folders in the "Blocks" folder prefaced as "Placeable"
The full list of custom mod blocks is as follows:
Placeable Blue Flower
Placeable Gras
Placeable Green Flower
Placeable Rainbow Flower
Placeable Red Flower
Placeable White Flower
