cyubePainter
by Quill Inkwell
verion 0.2.1

A in game set of world editing tools for cyubeVR. See included PDF for detailed instructions.