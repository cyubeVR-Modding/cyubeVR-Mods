Pixie Hunt
by Phildo, maintained by Quill Inkwell
Version 1.5

Installation Instructions:
===================================
The following zip is packaged to allow for easy installation of the Mod into your game.
Simply extract the contents of the provided zip file into your CyubeVR Mods Folder.
"cyubeVR/cyubeVR/Mods"
If you are updating the mod, allow it to overwrite any existing mod files it encounters.

Usage Instructions:
====================================
You will find the Pixie Block Recipe under the “Mod Blocks” category. Simply craft 8
Rainbow dye in a 2x2 pattern to create the Pixie Block. Now place the block into the
world and shoot it with an arrow. 

Uninstallation:
===================================
Navigate your your “APIMods” folder inside your cyubeVR “Mods” folder. Now delete the
following folder: “PixieHunt__V1”. You have now uninstalled the mod.

To remove the blocks navigate to your “Blocks” folder in your cyubeVR “Mods” folder.
Now delete the following folder: “PixieBlock”
