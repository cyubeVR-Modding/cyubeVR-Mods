BlockFactory v01 for cyubeVR

This mod makes 100 copies of any block you choose.

To install, place the folders contained within this zip file into the appropriate subfolders of the cyubeVR Mods folder:
   Place the folder "BlockFactory__V1"  into APIMods.
   Place the folder "BlockFactory"  into Blocks.

To use this mod:
   Craft the custom block "BlockFactory" following the crafting recipe.  You will need 4 iron ingots and 5 stone.
   Place the BlockFactory mod block somewhere in the world.
   Place the block you want to copy next to the mod block, at the base of the arrow on top of the mod block.
   Hit the mod block with the stick.
   A group of blocks 5 wide x 5 deep x 4 high of the same type as your input block will be generated at the point of the arrow.

Note:
   Any blocks already in the output area will be replaced by the newly generated blocks.
   