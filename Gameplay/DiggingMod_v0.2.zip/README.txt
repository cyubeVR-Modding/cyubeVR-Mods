Digging Mod
by Albertbz
Version 0.2

Installation Instructions:
===================================
To install the mod, simply copy the "Mods" folder you see in this .zip file into
the folder [GameInstallDirectory]/cyubeVR (if you don't see 
a "Mods" folder there, you're in the wrong place), and it should be ready to go.

In case you are updating the mod, you might have to first uninstall it and then
install the new version.

Once installed, make sure to restart cyubeVR :)


Uninstallation:
===================================
To uninstall the mod, simply delete the "diggingMod__v1" folder found in the
"APIMods" folder (it will be excavator__v1 if you're using v0.1).

If you would also like to delete the custom blocks, delete all of the blocks
with the prefix "digging".
In case you're using an older version, the prefix might be "albertbz".
