Excavator Mod
by Albertbz
Version 0.1

Installation Instructions:
===================================
To install the mod, simply copy the "Mods" folder you see in this .zip file into
the folder [GameInstallDirectory]/cyubeVR (if you don't see 
a "Mods" folder there, you're in the wrong place), and it should be ready to go.

In case you are updating the mod, you might have to first uninstall it and then
install the new version.

Once installed, be sure to restart cyubeVR :)


Uninstallation:
===================================
To uninstall the mod, simply delete the "excavator__v1" folder found in the
"APIMods" folder.

If you would also like to delete the custom blocks, delete the following
from the "Blocks" folder:
albertbz.check
albertbz.cross
albertbz.excavator
albertbz.exclamation
albertbz.inwards
albertbz.marker1
albertbz.marker2
albertbz.marker3
albertbz.marker4
albertbz.outwards
albertbz.settings
albertbz.up


In the case of an older version, you might also have to delete (if it 
exists):
albertbz.marker
