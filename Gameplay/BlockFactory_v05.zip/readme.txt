Block Factory v05 for cyubeVR

This mod makes 100 copies of any block you choose.

To install: 
   Place the folder "BlockFactory__V1"  into C:\Program Files (x86)\Steam\steamapps\common\cyubeVR\cyubeVR\Mods\APIMods
   Place all block folders into C:\Program Files (x86)\Steam\steamapps\common\cyubeVR\cyubeVR\Mods\Blocks

To use this mod:
   -- Craft the custom block called "Block Factory".  You can find the recipe under the "Mod Blocks" category in the Crafting Recipes tab.

   -- Place the Block Factory block next to the block that you want to copy.

   -- Hit the Block Factory block with any axe to set the copy direction.  The block you want to copy should be at the base of the arrow.

   -- Hit the Block Factory block with the stick to place 100 copies of your input block into the world.  These blocks will be placed at the point of the arrow.  Any blocks already in the output area will be replaced by the newly generated blocks.

   -- Hit the Block Factory block with any pickaxe to place 100 copies of your input block directly into your inventory (if you have enough space).  For blocks that normally drop items when broken (flowers, ores, etc), those items will be added to your inventory instead (dyes, nuggets, etc).  Copying a crystal block will only add 2 crystals to your inventory.

   -- To remove the Block Factory block, hit it with any axe type until it returns to its original state (no arrows).  It can then be broken with a pickaxe.

Known Issues:
   -- The mod block will sometimes register more than one hit.  This may cause a direction to be skipped over when setting the copy direction, or more than 100 blocks/items to be added to your inventory.

Version History:
   v05: Added ability to add copies directly to your inventory.

   v04: Fixed incorrect number of copies being placed.
        Reworded readme and tutorial with clearer instructions.

   v03: Added ability to change copy direction.
        Added in-game tutorial page.

   v02: Compatibility update for cyubeVR beta 51.29.  Now can copy torches.

   v01: First release version.
   